<?php
interface IToJson{
    public function toJson();
}
?>